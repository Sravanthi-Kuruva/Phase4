export class GlobalConstants {
    public static score: number = 0;
}